<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include 'Persona.php';
        //require_once 'Persona.php';
        include 'Studente.php';
        include 'Dirigente.php';
        
        //Simula una lettura dati che può avvenire tramite FORM HTML,
        //tramite DB, tramite lettura file, ecc.
        $nome1 = "Loris";     
        $cognome1 = "Penserini";
        $eta1 = "50";
        $interessi1 = "DRONI";    
        
        $nome2 = "Mario";     
        $cognome2 = "Rossi";
        $eta2 = "40";
        $interessi2 = "Pesca"; 
        
        $nome3 = "Giovanna";     
        $cognome3 = "Rossini";
        $eta3 = "40";
        $interessi3 = "Opera"; 
        
        //CREO GLI OGGETTI "Persona1", "Studente1" e "Dirigente1"
        $Persona1 = new Persona($nome1, $cognome1, $eta1, $interessi1);
        $Studente1 = new Studente($nome2, $cognome2, $eta2, $interessi2);
        $Studente1->setIndStudio("Sistemi Informativi Aziendali");
        $Dirigente1 = new Dirigente($nome3, $cognome3, $eta3, $interessi3);
        $Dirigente1->setScuola("IIS POLO3 FANO");
         
        echo "SALUTO DI PERSONA_1: <br>".$Persona1->getPagBenvenuto();
        echo "<br><br>SALUTO DI STUDENTE_1: <br>".$Studente1->getPagBenvenutoStud();   
        echo "<br><br>SALUTO DI DIRIGENTE_1: <br>".$Dirigente1->getPagBenvenutoDir();
        ?>
    </body>
</html>
